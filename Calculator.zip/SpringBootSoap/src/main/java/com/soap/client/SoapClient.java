package com.soap.client;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.soap.wsdl.Add;
import com.soap.wsdl.AddResponse;
import com.soap.wsdl.Divide;
import com.soap.wsdl.DivideResponse;
import com.soap.wsdl.Multiply;
import com.soap.wsdl.MultiplyResponse;
import com.soap.wsdl.Subtract;
import com.soap.wsdl.SubtractResponse;

public class SoapClient extends WebServiceGatewaySupport {

	/**
	 * METODO QUE SE ENCARGA DE SUMAR DOS NUMEROS
	 * @param numeroA
	 * @param numeroB
	 * @return AddResponse
	 */
	public AddResponse getAddResponse(int numeroA, int numeroB) {
		
		Add addRequest = new Add();
		addRequest.setIntA(numeroA);
		addRequest.setIntB(numeroB);
		
		SoapActionCallback soapActionCallback = new SoapActionCallback("http://tempuri.org/Add");
		
		AddResponse addResponse = (AddResponse) getWebServiceTemplate().marshalSendAndReceive("http://www.dneonline.com/calculator.asmx", addRequest, soapActionCallback);
		
		return addResponse;
	}
	
	
	/**
	 * METODO QUE SE ENCARGA DE RESTAR DOS NUMEROS
	 * @param numeroA
	 * @param numeroB
	 * @return SubtractResponse
	 */
	public SubtractResponse getSubtractResponse(int numeroA, int numeroB) {
		
		Subtract subtractRequest = new Subtract();
		subtractRequest.setIntA(numeroA);
		subtractRequest.setIntB(numeroB);
		
		SoapActionCallback soapActionCallback = new SoapActionCallback("http://tempuri.org/Subtract");
		
		SubtractResponse subtractResponse = (SubtractResponse) getWebServiceTemplate().marshalSendAndReceive("http://www.dneonline.com/calculator.asmx", subtractRequest, soapActionCallback);
		
		return subtractResponse;
	}
	
	
	/**
	 * METODO QUE SE ENCARGA DE MULTIPLICAR DOS NUMEROS
	 * @param numeroA
	 * @param numeroB
	 * @return MultiplyResponse
	 */
	public MultiplyResponse getMultiplyResponse(int numeroA, int numeroB) {
		
		Multiply multiplyRequest = new Multiply();
		multiplyRequest.setIntA(numeroA);
		multiplyRequest.setIntB(numeroB);
		
		SoapActionCallback soapActionCallback = new SoapActionCallback("http://tempuri.org/Multiply");
		
		MultiplyResponse multiplyResponse = (MultiplyResponse) getWebServiceTemplate().marshalSendAndReceive("http://www.dneonline.com/calculator.asmx", multiplyRequest, soapActionCallback);
		
		return multiplyResponse;
	}
	
	
	/**
	 * METODO QUE SE ENCARGA DE DIVIDIR DOS NUMEROS
	 * @param numeroA
	 * @param numeroB
	 * @return DivideResponse
	 */
	public DivideResponse getDivideResponse(int numeroA, int numeroB) {
		
		Divide divideRequest = new Divide();
		divideRequest.setIntA(numeroA);
		divideRequest.setIntB(numeroB);
		
		SoapActionCallback soapActionCallback = new SoapActionCallback("http://tempuri.org/Divide");
		
		DivideResponse divideResponse = (DivideResponse) getWebServiceTemplate().marshalSendAndReceive("http://www.dneonline.com/calculator.asmx", divideRequest, soapActionCallback);
		
		return divideResponse;
	}
	
	
}
