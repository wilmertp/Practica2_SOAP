<?php

$wsdl = 'http://www.dneonline.com/calculator.asmx?WSDL';

$client = new SoapClient($wsdl);

//Metodo para la suma
$resultsuma = $client->Add(array('intA' => 4, 'intB' => 1));
echo "El resultado de la suma es: $resultsuma->AddResult" . "<br><br>";

//Metodo para la resta
$resultresta = $client->Subtract(array('intA' => 4, 'intB' => 2));
echo "El resultado de la resta es: $resultresta->SubtractResult" . "<br><br>";

//Metodo para la multiplicacion
$resultmultiplicacion = $client->Multiply(array('intA' => 4, 'intB' => 5));
echo "El resultado de la multiplicacion es: $resultmultiplicacion->MultiplyResult" . "<br><br>";

//Metodo para la division
$resultdivide = $client->Divide(array('intA' => 10, 'intB' => 5));
echo "El resultado de la division es: $resultdivide->DivideResult" . "<br><br>";

